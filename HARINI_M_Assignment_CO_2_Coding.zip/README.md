# Python Programming Assignment CO_2 - Extracted Code

This folder contains the seven Python coding tasks shown in the assignment PDF.
The Task 2 while-loop and for-loop versions are provided separately.
Code that continued onto the following page in the PDF has been combined into
its corresponding task file (Tasks 3, 5, and 6).

Run each `.py` file with Python 3. Task 2 and Task 3 prompt for user input.
Tasks 4 and 7 compare execution time, which varies by computer and Python version.
